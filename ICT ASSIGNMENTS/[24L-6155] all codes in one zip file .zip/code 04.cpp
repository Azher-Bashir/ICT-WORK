//#include <iostream>
//
//using namespace std;
//
//static void ordered_pair(int start, int stop)
//{
//	for (int i = start; i <= stop; i++)
//	{
//		for (int j = i; j <= stop; j++)
//		{
//			cout << "(" << i << " , " << j << ")" << " ";
//		}
//		cout << endl;
//	}
//	//return;
//}
//int main()
//{
//	int start, stop;
//	cout << "Enter the starting value: ";
//	cin >> start;
//	cout << "Enter thr ending value: ";
//	cin >> stop;
//	cout << endl;
//	ordered_pair(start, stop);
//	return 0;
//}
