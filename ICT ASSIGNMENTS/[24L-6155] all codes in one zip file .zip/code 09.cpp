//#include <iostream>
//#include <cmath>
//
//using namespace std;
//
//static int power(int base, int exp)
//{
//	if (exp == 0)
//	{
//		return 1;
//	}
//	else
//	{
//		return base * power(base, exp - 1);
//	}
//}
//
//int main()
//{
//	int num, exp;
//	cout << "Enter the number: ";
//	cin >> num;
//	cout << "Enter the exponenet: ";
//	cin >> exp;
//	cout << "Result: " << power(num, exp);
//	return 0;
//}